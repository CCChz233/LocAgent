## FederatedScope Documentation
Please run the following commands from this directory to compile the documentation. Note that FederatedScope must be installed first.

```
pip install -r requirements-doc.txt
make html
```
