Federated Natural Language Processing  Module References
=======================

federatedscope.nlp.dataset
-----------------------

.. automodule:: federatedscope.nlp.dataset
    :members:
    :private-members:

federatedscope.nlp.dataloader
-----------------------

.. automodule:: federatedscope.nlp.dataloader
    :members:
    :private-members:

federatedscope.nlp.model
-----------------------

.. automodule:: federatedscope.nlp.model
    :members:
    :private-members:

federatedscope.nlp.trainer
-----------------------

.. automodule:: federatedscope.nlp.trainer
    :members:
    :private-members:
