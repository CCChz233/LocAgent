Auto-tuning Module References
=======================

federatedscope.autotune.choice_types
-----------------------

.. automodule:: federatedscope.autotune.choice_types
    :members:
    :private-members:

federatedscope.autotune.algos
-----------------------

.. automodule:: federatedscope.autotune.algos
    :show-inheritance:
    :members:
    :private-members:

federatedscope.autotune.hpbandster
-----------------------

.. automodule:: federatedscope.autotune.hpbandster
    :members:
    :private-members:

federatedscope.autotune.smac
-----------------------

.. automodule:: federatedscope.autotune.smac
    :members:
    :private-members:

federatedscope.autotune.utils
-----------------------

.. automodule:: federatedscope.autotune.utils
    :members:
    :private-members:
