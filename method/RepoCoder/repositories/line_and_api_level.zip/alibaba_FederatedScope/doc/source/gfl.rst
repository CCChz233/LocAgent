Federated Graph Learning  Module References
=======================

federatedscope.gfl.dataset
-----------------------

.. automodule:: federatedscope.gfl.dataset
    :members:
    :private-members:

federatedscope.gfl.dataloader
-----------------------

.. automodule:: federatedscope.gfl.dataloader
    :members:
    :private-members:

federatedscope.gfl.model
-----------------------

.. automodule:: federatedscope.gfl.model
    :members:
    :private-members:

federatedscope.gfl.trainer
-----------------------

.. automodule:: federatedscope.gfl.trainer
    :members:
    :private-members:
