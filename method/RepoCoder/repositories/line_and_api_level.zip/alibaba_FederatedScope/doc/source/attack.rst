Attack Module References
======================

federatedscope.attack.privacy_attacks
-------------------------------------------

.. automodule:: federatedscope.attack.privacy_attacks
    :members:
    :private-members:


federatedscope.attack.worker_as_attacker
-------------------------------------------

.. automodule:: federatedscope.attack.worker_as_attacker
    :members:
    :private-members:

federatedscope.attack.auxiliary
--------------------------------

.. automodule:: federatedscope.attack.auxiliary
    :members:
    :private-members:

federatedscope.attack.trainer
---------------------------------

.. automodule:: federatedscope.attack.trainer
    :members:
    :private-members:







