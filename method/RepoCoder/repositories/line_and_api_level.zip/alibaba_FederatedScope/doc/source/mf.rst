Federated Matrix Factorization Module References
=======================

federatedscope.mf.dataset
-----------------------

.. automodule:: federatedscope.mf.dataset
    :members:
    :private-members:

federatedscope.mf.model
-----------------------

.. automodule:: federatedscope.mf.model
    :members:
    :private-members:

federatedscope.mf.dataloader
-----------------------

.. automodule:: federatedscope.mf.dataloader
    :members:
    :private-members:

federatedscope.mf.trainer
-----------------------

.. automodule:: federatedscope.mf.trainer
    :members:
    :private-members:
