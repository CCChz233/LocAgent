cd ../FederatedScope/federatedscope/

python main.py --cfg contrib/configs/config_ditto.yaml --cfg_client contrib/configs/config_client_ditto.yaml outdir exp/sts_imdb_squad/ditto/
