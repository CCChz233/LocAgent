cd ../FederatedScope/federatedscope/

python main.py --cfg contrib/configs/config_fedbn.yaml --cfg_client contrib/configs/config_client_fedbn.yaml outdir exp/sts_imdb_squad/fedbn/
