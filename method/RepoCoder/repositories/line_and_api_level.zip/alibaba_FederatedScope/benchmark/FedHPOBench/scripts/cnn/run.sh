# --1--
bash run_hpo_femnist_48.sh 0 0.0 1 16 &
bash run_hpo_femnist_48.sh 1 0.0 1 32 &
bash run_hpo_femnist_48.sh 2 0.0 1 64 &
bash run_hpo_femnist_48.sh 3 0.0 2 16 &
bash run_hpo_femnist_48.sh 0 0.0 2 32 &
bash run_hpo_femnist_48.sh 1 0.0 2 64 &
bash run_hpo_femnist_48.sh 2 0.0 3 16 &
bash run_hpo_femnist_48.sh 3 0.0 3 32 &
# --2--
bash run_hpo_femnist_48.sh 0 0.0 3 64 &
bash run_hpo_femnist_48.sh 1 0.0 4 16 &
bash run_hpo_femnist_48.sh 2 0.0 4 32 &
bash run_hpo_femnist_48.sh 3 0.0 4 64 &
bash run_hpo_femnist_48.sh 0 0.001 1 16 &
bash run_hpo_femnist_48.sh 1 0.001 1 32 &
bash run_hpo_femnist_48.sh 2 0.001 1 64 &
bash run_hpo_femnist_48.sh 3 0.001 2 16 &
# --3--
bash run_hpo_femnist_48.sh 0 0.001 2 32 &
bash run_hpo_femnist_48.sh 1 0.001 2 64 &
bash run_hpo_femnist_48.sh 2 0.001 3 16 &
bash run_hpo_femnist_48.sh 3 0.001 3 32 &
bash run_hpo_femnist_48.sh 0 0.001 3 64 &
bash run_hpo_femnist_48.sh 1 0.001 4 16 &
bash run_hpo_femnist_48.sh 2 0.001 4 32 &
bash run_hpo_femnist_48.sh 3 0.001 4 64 &
# --4--
bash run_hpo_femnist_48.sh 0 0.01 1 16 &
bash run_hpo_femnist_48.sh 1 0.01 1 32 &
bash run_hpo_femnist_48.sh 2 0.01 1 64 &
bash run_hpo_femnist_48.sh 3 0.01 2 16 &
bash run_hpo_femnist_48.sh 0 0.01 2 32 &
bash run_hpo_femnist_48.sh 1 0.01 2 64 &
bash run_hpo_femnist_48.sh 2 0.01 3 16 &
bash run_hpo_femnist_48.sh 3 0.01 3 32 &
# --5--
bash run_hpo_femnist_48.sh 0 0.01 3 64 &
bash run_hpo_femnist_48.sh 1 0.01 4 16 &
bash run_hpo_femnist_48.sh 2 0.01 4 32 &
bash run_hpo_femnist_48.sh 3 0.01 4 64 &
bash run_hpo_femnist_48.sh 0 0.1 1 16 &
bash run_hpo_femnist_48.sh 1 0.1 1 32 &
bash run_hpo_femnist_48.sh 2 0.1 1 64 &
bash run_hpo_femnist_48.sh 3 0.1 2 16 &
# --6--
bash run_hpo_femnist_48.sh 0 0.1 2 32 &
bash run_hpo_femnist_48.sh 1 0.1 2 64 &
bash run_hpo_femnist_48.sh 2 0.1 3 16 &
bash run_hpo_femnist_48.sh 3 0.1 3 32 &
bash run_hpo_femnist_48.sh 0 0.1 3 64 &
bash run_hpo_femnist_48.sh 1 0.1 4 16 &
bash run_hpo_femnist_48.sh 2 0.1 4 32 &
bash run_hpo_femnist_48.sh 3 0.1 4 64 &
