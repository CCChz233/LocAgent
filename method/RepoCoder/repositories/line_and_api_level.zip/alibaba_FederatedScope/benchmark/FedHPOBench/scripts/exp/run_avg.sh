bash run_mode.sh 10101@openml tabular mlp 3 avg

bash run_mode.sh 146818@openml tabular mlp 1 avg

bash run_mode.sh 146821@openml tabular mlp 3 avg

bash run_mode.sh 146822@openml tabular mlp 2 avg