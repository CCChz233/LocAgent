from federatedscope.core.secret_sharing.secret_sharing import \
    AdditiveSecretSharing
