from federatedscope.core.proto.gRPC_comm_manager_pb2 import *
from federatedscope.core.proto.gRPC_comm_manager_pb2_grpc import *
