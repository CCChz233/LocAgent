from federatedscope.core.splitters.generic.lda_splitter import LDASplitter
from federatedscope.core.splitters.generic.iid_splitter import IIDSplitter

__all__ = ['LDASplitter', 'IIDSplitter']
