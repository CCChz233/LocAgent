from federatedscope.core.splitters.base_splitter import BaseSplitter

__all__ = ['BaseSplitter']
